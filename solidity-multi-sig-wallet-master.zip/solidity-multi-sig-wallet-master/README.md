# Truffle + Multi-sig Smart Contract

## Environment
```
node : v16.15.0
npm : v8.5.5
```

## Start
```
$ npm install -g truffle
$ truffle develop
truffle(develop)> truffle migrate
``` 

## Then
After truffle develop, you can see 10 test acconts and private keys. Also, we can see the truffle develop's address (ex) ip address:8545) 

Then we could connect the Metamask by connecting this address and add the account in Metamask wallet.
