# Multi-sig wallet

## Environment
``` 
node: v14.0.0
npm : v6.14.4
```

## Prerequisite
```
Set up Truffle (The blockchain is operated by truffle)
```
## Start
```
$ npm install
$ npm start
```
